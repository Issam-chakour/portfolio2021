const myPara = document.getElementById('myPara');
        function clik() {
            myPara.classList.toggle("red-bg");
        };